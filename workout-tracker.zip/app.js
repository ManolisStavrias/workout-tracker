import { loadWorkouts, saveWorkouts, loadExercises, saveExercises, loadSettings, saveSettings } from './storage.js';
import { calc1RM, suggestWeightFrom1RM, roundToStep } from './metrics.js';

const DEFAULT_EXERCISES = [
  { id: 'ex_bench', name: 'Bench Press', muscle: 'Chest', movement: 'Horizontal Push', best1RM: null, manual1RM: false, oneRMHistory: [] },
  { id: 'ex_squat', name: 'Squat', muscle: 'Legs', movement: 'Squat', best1RM: null, manual1RM: false, oneRMHistory: [] },
  { id: 'ex_dead', name: 'Deadlift', muscle: 'Full Body', movement: 'Hinge', best1RM: null, manual1RM: false, oneRMHistory: [] },
  { id: 'ex_ohp', name: 'Overhead Press', muscle: 'Shoulders', movement: 'Vertical Push', best1RM: null, manual1RM: false, oneRMHistory: [] },
  { id: 'ex_pull', name: 'Pull-up', muscle: 'Back', movement: 'Vertical Pull', best1RM: null, manual1RM: false, oneRMHistory: [] },
  { id: 'ex_row', name: 'Barbell Row', muscle: 'Back', movement: 'Horizontal Pull', best1RM: null, manual1RM: false, oneRMHistory: [] }
];

let SETTINGS = {
  strategy: 'upperBound',
  minIncreasePct: 0.005,
  requireLowRIR: true,
  maxRIR: 1,
  alpha: 0.25,
  weightStep: 2.5
};

let workouts = {};
let exercises = [];
let currentDate = null;

const $ = (sel, el=document) => el.querySelector(sel);
const $$ = (sel, el=document) => Array.from(el.querySelectorAll(sel));

function uid(prefix='id'){return prefix+Math.random().toString(36).slice(2,9);}  
function todayYMD(){const d=new Date();const tz=new Date(d.getTime()-d.getTimezoneOffset()*60000);return tz.toISOString().slice(0,10);}

function loadFromStorage(){
  workouts = loadWorkouts() || {};
  exercises = loadExercises() || [];
  if(!exercises.length) exercises = [...DEFAULT_EXERCISES];
  exercises = exercises.map(e => ({ id: e.id || uid('ex_'), name: e.name, muscle: e.muscle, movement: e.movement, best1RM: e.best1RM ?? null, manual1RM: e.manual1RM || false, oneRMHistory: e.oneRMHistory || [] }));
}

function loadSettingsLocal(){
  const s = loadSettings();
  if(s) SETTINGS = Object.assign({}, SETTINGS, s);
}

function saveSettingsLocal(){ saveSettings(SETTINGS); }

function saveWorkoutsLocal(){ saveWorkouts(workouts); }
function saveExercisesLocal(){ saveExercises(exercises); }

function emptyExercise(){return {filterBy:'muscle',category:'',exercise:'',exerciseNote:'',plannedMin:'',plannedMax:'',sets:[]};}
function emptySet(){return {kg:'',reps:'',rir:'',oneRM:'',setNote:''};}

function ensureDate(date){if(!workouts[date] || !Array.isArray(workouts[date])) workouts[date]=[emptyExercise(),emptyExercise(),emptyExercise()];}

function getUnique(list,key){return [...new Set(list.map(x=>x[key]).filter(Boolean))].sort();}
function filteredExercises(filterBy,cat){return exercises.filter(e=>filterBy==='movement'?e.movement===cat:e.muscle===cat);}

function notify(msg, ok=true){
  const t = $('#toast'); const box = t.firstElementChild;
  box.textContent = msg; box.className = ok ? 'rounded-lg bg-green-600 text-white px-4 py-2 shadow' : 'rounded-lg bg-rose-600 text-white px-4 py-2 shadow';
  t.style.display='block'; t.classList.remove('hidden');
  clearTimeout(t._timer);
  t._timer = setTimeout(()=>{ t.style.display='none'; }, 3200);
}

function renderExercises(){
  const container=$('#exerciseContainer');
  container.innerHTML='';
  (workouts[currentDate]||[]).forEach((exObj,idx)=>container.appendChild(buildExercise(exObj,idx)));
}

function buildExercise(exObj,idx){
  const tpl=$('#exerciseTemplate').content.firstElementChild.cloneNode(true);
  const filterSel=$('.filterBy',tpl);
  const catSel=$('.category',tpl);
  const exSel=$('.exercise',tpl);
  const setsDiv=$('.sets',tpl);
  const exNote=$('.exerciseNote',tpl);
  const plannedMinInp=$('.plannedMin',tpl);
  const plannedMaxInp=$('.plannedMax',tpl);
  const suggestedSpan=$('.suggestedWeight',tpl);

  filterSel.value=exObj.filterBy;

  function refreshCats(){
    catSel.innerHTML='<option value="">— Select —</option>';
    getUnique(exercises,filterSel.value==='movement'?'movement':'muscle').forEach(c=>{
      const o=document.createElement('option');o.value=c;o.textContent=c;catSel.appendChild(o);
    });
    catSel.value=exObj.category||'';
  }
  function refreshEx(){
    exSel.innerHTML='<option value="">— Select Exercise —</option>';
    filteredExercises(filterSel.value,catSel.value).forEach(e=>{
      const o=document.createElement('option');o.value=e.name;o.textContent=e.name;exSel.appendChild(o);
    });
    exSel.value=exObj.exercise||'';
    updateSuggestion();
  }
  refreshCats();refreshEx();

  filterSel.addEventListener('change',()=>{exObj.filterBy=filterSel.value;exObj.category='';exObj.exercise='';refreshCats();refreshEx();saveWorkoutsLocal();});
  catSel.addEventListener('change',()=>{exObj.category=catSel.value;exObj.exercise='';refreshEx();saveWorkoutsLocal();});
  exSel.addEventListener('change',()=>{exObj.exercise=exSel.value; updateSuggestion(); saveWorkoutsLocal();});

  plannedMinInp.value = exObj.plannedMin || '';
  plannedMaxInp.value = exObj.plannedMax || '';
  plannedMinInp.addEventListener('input', ()=>{ exObj.plannedMin = plannedMinInp.value; updateSuggestion(); saveWorkoutsLocal(); });
  plannedMaxInp.addEventListener('input', ()=>{ exObj.plannedMax = plannedMaxInp.value; updateSuggestion(); saveWorkoutsLocal(); });

  function updateSuggestion(){
    const exName = exSel.value;
    const stored = exercises.find(e => e.name === exName);
    const stored1RM = stored && stored.best1RM ? stored.best1RM : null;
    const target = exObj.plannedMin || exObj.plannedMax || '';
    const suggested = stored1RM && target ? suggestWeightFrom1RM(stored1RM, target, SETTINGS.weightStep) : '';
    suggestedSpan.textContent = suggested ? suggested + ' kg' : '—';
  }

  function renderSets(){
    setsDiv.innerHTML='';
    exObj.sets.forEach((set,setIdx)=>{
      const s=$('#setTemplate').content.firstElementChild.cloneNode(true);
      const inpKg=$('.kg',s);
      const inpReps=$('.reps',s);
      const inpRir=$('.rir',s);
      const inp1=$('.oneRM',s);
      const inpNote=$('.setNote',s);

      inpKg.value=set.kg;
      inpReps.value=set.reps;
      inpRir.value=set.rir;
      inp1.value=set.oneRM;
      inpNote.value=set.setNote;

      function update1RM(){
        const val = calc1RM(inpKg.value, inpReps.value, inpRir.value);
        inp1.value = val === '' ? '' : val;
        set.oneRM = inp1.value;
      }

      inpKg.addEventListener('input',()=>{ set.kg=inpKg.value; update1RM(); saveWorkoutsLocal(); checkAndMaybeUpdate1RM(set, exObj); });
      inpReps.addEventListener('input',()=>{ set.reps=inpReps.value; update1RM(); saveWorkoutsLocal(); checkAndMaybeUpdate1RM(set, exObj); });
      inpRir.addEventListener('input',()=>{ set.rir=inpRir.value; update1RM(); saveWorkoutsLocal(); checkAndMaybeUpdate1RM(set, exObj); });
      inpNote.addEventListener('input',()=>{ set.setNote=inpNote.value; saveWorkoutsLocal(); });

      $('.deleteSet',s).addEventListener('click',()=>{ exObj.sets.splice(setIdx,1); saveWorkoutsLocal(); renderSets(); if(exObj.exercise) recomputeBestFromSets(exObj.exercise); });

      update1RM();

      setsDiv.appendChild(s);
    });
  }
  renderSets();

  $('.addSetBtn',tpl).addEventListener('click',()=>{ 
    const last = exObj.sets[exObj.sets.length-1];
    const newSet = emptySet();
    if(last && last.kg) newSet.kg = last.kg;
    exObj.sets.push(newSet); saveWorkoutsLocal(); renderSets();
  });
  $('.deleteExercise',tpl).addEventListener('click',()=>{ workouts[currentDate].splice(idx,1); saveWorkoutsLocal(); renderExercises(); });

  exNote.value = exObj.exerciseNote || '';
  exNote.addEventListener('input', ()=>{ exObj.exerciseNote = exNote.value; saveWorkoutsLocal(); });

  return tpl;
}

function addExercise(){ workouts[currentDate].push(emptyExercise()); saveWorkoutsLocal(); renderExercises(); }

function loadDate(d){ currentDate=d; ensureDate(d); renderExercises(); }

function renderExerciseList(){
  const tbody=$('#exerciseList'); tbody.innerHTML='';
  exercises.forEach((ex,idx)=>{
    const tr=document.createElement('tr');
    const best = ex.best1RM ? (ex.best1RM + ' kg') : '-';
    tr.innerHTML=`<td class="py-1 pr-2">${ex.name}</td><td class="py-1 pr-2">${ex.muscle}</td><td class="py-1 pr-2">${ex.movement}</td><td class="py-1 pr-2">${best}</td><td class="py-1 pr-0 text-right"><button data-idx='${idx}' class='editEx px-2 py-1 border rounded'>Edit</button></td>`;
    tbody.appendChild(tr);
  });
  $$('.editEx',tbody).forEach(btn=>btn.addEventListener('click',e=>{
    const idx=parseInt(e.target.dataset.idx);
    openEditExercise(idx);
  }));
}

function openEditExercise(idx){
  const ex = exercises[idx];
  const modal = document.createElement('div');
  modal.className = 'fixed inset-0 bg-black/40 flex items-center justify-center z-50';
  modal.innerHTML = `
    <div class="bg-white p-4 rounded-lg max-w-md w-full">
      <h3 class="font-semibold mb-2">Edit Exercise</h3>
      <div class="grid gap-2">
        <input id="editName" class="px-3 py-2 border rounded" value="${ex.name}" />
        <input id="editMuscle" class="px-3 py-2 border rounded" value="${ex.muscle}" />
        <input id="editMovement" class="px-3 py-2 border rounded" value="${ex.movement}" />
        <input id="editBest1" type="number" step="0.1" class="px-3 py-2 border rounded" value="${ex.best1RM ?? ''}" placeholder="Best 1RM (optional)" />
        <div class="flex gap-2 justify-end">
          <button id="saveEx" class="px-3 py-2 bg-emerald-500 text-white rounded">Save</button>
          <button id="deleteEx" class="px-3 py-2 bg-rose-500 text-white rounded">Delete</button>
          <button id="cancelEx" class="px-3 py-2 bg-slate-300 rounded">Cancel</button>
        </div>
      </div>
    </div>`;
  document.body.appendChild(modal);
  $('#cancelEx', modal).addEventListener('click', ()=>{ modal.remove(); });
  $('#deleteEx', modal).addEventListener('click', ()=>{
    if(!confirm('Delete exercise from list? This will not remove historical workout entries.')) return;
    exercises.splice(idx,1); saveExercisesLocal(); renderExerciseList(); renderExercises(); modal.remove();
  });
  $('#saveEx', modal).addEventListener('click', ()=>{
    const newName = $('#editName', modal).value.trim();
    const newMuscle = $('#editMuscle', modal).value.trim();
    const newMove = $('#editMovement', modal).value.trim();
    const newBest = $('#editBest1', modal).value.trim();
    if(!newName || !newMuscle || !newMove) return alert('Fill name/muscle/movement');
    const oldName = ex.name;
    ex.name = newName; ex.muscle = newMuscle; ex.movement = newMove;
    if(newBest !== ''){ ex.best1RM = Number(newBest); ex.manual1RM = true; } else { ex.best1RM = null; ex.manual1RM = false; }
    for(const date of Object.keys(workouts)){
      (workouts[date]||[]).forEach(entry => { if(entry.exercise === oldName) entry.exercise = newName; });
    }
    saveExercisesLocal(); saveWorkoutsLocal(); renderExerciseList(); renderExercises(); modal.remove();
  });
}

function addExerciseToList(){
  const name=$('#exName').value.trim(),muscle=$('#exMuscle').value.trim(),movement=$('#exMovement').value.trim();
  const bestVal = $('#exBest1RM').value.trim();
  if(!name||!muscle||!movement) return alert('Fill all fields');
  if(exercises.some(e=>e.name.toLowerCase()===name.toLowerCase())) return alert('Exists');
  exercises.push({ id: uid('ex_'), name,muscle,movement,best1RM: bestVal?Number(bestVal):null, manual1RM: !!bestVal, oneRMHistory: [] }); saveExercisesLocal(); $('#exName').value=''; $('#exMuscle').value=''; $('#exMovement').value=''; $('#exBest1RM').value=''; renderExerciseList(); renderExercises();
}

function checkAndMaybeUpdate1RM(set, exObj){
  try{
    const kg = parseFloat(set.kg);
    const reps = parseFloat(set.reps);
    const rir = set.rir === '' ? 0 : parseFloat(set.rir);
    if(!kg || !reps) return;
    const est = calc1RM(kg,reps,rir);
    if(!est) return;

    const master = exercises.find(e => e.name === exObj.exercise);
    if(!master) return;

    if(master.manual1RM) return;

    const plannedMax = exObj.plannedMax ? Number(exObj.plannedMax) : null;
    const plannedMin = exObj.plannedMin ? Number(exObj.plannedMin) : null;
    const requiredReps = plannedMax || plannedMin || null;
    if(requiredReps === null) return;
    if(reps < requiredReps) return;

    if(SETTINGS.requireLowRIR && rir !== null && rir > SETTINGS.maxRIR) return;

    const currentBest = master.best1RM ? Number(master.best1RM) : 0;
    if(est <= currentBest * (1 + SETTINGS.minIncreasePct)) return;

    const estRounded = Math.round(est*10)/10;
    if(SETTINGS.strategy === 'smoothed' && currentBest > 0){
      master.best1RM = Math.round(((SETTINGS.alpha * estRounded) + ((1-SETTINGS.alpha) * currentBest)) * 10) / 10;
    } else {
      master.best1RM = estRounded;
    }
    master.manual1RM = false;
    master.oneRMHistory = master.oneRMHistory || [];
    master.oneRMHistory.push({ date: currentDate, est1RM: estRounded });
    saveExercisesLocal();
    renderExercises();
    renderExerciseList();
    notify(`Updated 1RM for ${master.name}: ${master.best1RM} kg (est ${estRounded} kg)`);
  }catch(e){console.error(e)}
}

function recomputeBestFromSets(exName){
  const master = exercises.find(e => e.name === exName);
  if(!master) return;
  if(master.manual1RM) return;

  const ests = [];
  for(const [date, list] of Object.entries(workouts)){
    (list||[]).forEach(entry=>{
      if(entry.exercise !== exName) return;
      (entry.sets||[]).forEach(s => {
        const kg = parseFloat(s.kg); const reps = parseFloat(s.reps); const rir = s.rir === '' ? 0 : parseFloat(s.rir);
        if(!kg || !reps) return;
        const est = calc1RM(kg, reps, rir);
        if(est) ests.push({date,est});
      });
    });
  }
  const prevBest = master.best1RM ? Number(master.best1RM) : 0;
  const maxEst = ests.length ? Math.max(...ests.map(x=>x.est)) : null;
  if(maxEst === null){ master.best1RM = null; master.oneRMHistory = []; saveExercisesLocal(); renderExerciseList(); renderExercises(); return; }
  master.best1RM = Math.round(maxEst*10)/10;
  master.oneRMHistory = ests.map(x=>({date:x.date, est1RM: Math.round(x.est*10)/10}));
  saveExercisesLocal();
  renderExerciseList();
  renderExercises();
}

function exportCSV(){
  const rows=[];
  for(const [date,exs] of Object.entries(workouts)){
    exs.forEach(ex=>{
      const exName = ex.exercise || '';
      const exNote = ex.exerciseNote || '';
      const master = exercises.find(e => e.name === exName);
      const best1 = master && master.best1RM ? master.best1RM : '';
      if(!ex.sets || !ex.sets.length) return;
      ex.sets.forEach(set=>{
        rows.push({date,exercise:exName,best1RM:best1,exerciseNote:exNote,kg:set.kg,reps:set.reps,rir:set.rir,oneRM:set.oneRM,setNote:set.setNote});
      });
    });
  }
  const headers=['date','exercise','best1RM','exerciseNote','kg','reps','rir','oneRM','setNote'];
  const lines=[headers.join(',')].concat(rows.map(r=>headers.map(h=>('"'+String(r[h]||'').replaceAll('"','""')+'"')).join(','))).join('\n');
  const blob=new Blob([lines],{type:'text/csv'});
  const a=document.createElement('a'); a.href=URL.createObjectURL(blob); a.download='workouts.csv'; a.click(); URL.revokeObjectURL(a.href);
}

function clearWorkouts(){ if(confirm('Clear workouts?')){ workouts={}; saveWorkoutsLocal(); loadDate($('#dateInput').value); } }
function resetExercises(){ if(confirm('Reset exercises?')){ exercises=[...DEFAULT_EXERCISES]; saveExercisesLocal(); renderExerciseList(); renderExercises(); } }
function clearAll(){ if(confirm('Clear all data?')){ localStorage.removeItem('wt_workouts_v4'); localStorage.removeItem('wt_exercises_v3'); localStorage.removeItem('wt_settings_v1'); loadFromStorage(); loadSettingsLocal(); loadDate($('#dateInput').value); renderExerciseList(); } }

function showScreen(id){ $$('.screen').forEach(s=>s.classList.add('hidden')); $(id).classList.remove('hidden'); }

function copyPrevious(){
  const dates = Object.keys(workouts).filter(d=>d!==currentDate).sort().reverse();
  let found = null;
  for(const d of dates){
    const exs = workouts[d]||[];
    if(exs.some(e=>e.exercise)){ found = d; break; }
  }
  if(!found){ alert('No previous workout found to copy.'); return; }
  if(!confirm('Copy workout from '+found+' to '+currentDate+'? This will overwrite current date.')) return;
  workouts[currentDate] = JSON.parse(JSON.stringify(workouts[found]));
  saveWorkoutsLocal();
  renderExercises();
}

function reflectSettingsToUI(){
  $('#settingStrategy').value = SETTINGS.strategy;
  $('#settingMinInc').value = (SETTINGS.minIncreasePct * 100).toFixed(2);
  $('#settingRequireRIR').checked = !!SETTINGS.requireLowRIR;
  $('#settingMaxRIR').value = SETTINGS.maxRIR;
  $('#settingAlpha').value = SETTINGS.alpha;
  $('#settingWeightStep').value = SETTINGS.weightStep;
}

function applySettingsFromUI(){
  SETTINGS.strategy = $('#settingStrategy').value;
  const percent = parseFloat($('#settingMinInc').value);
  SETTINGS.minIncreasePct = isFinite(percent) ? Math.max(0, percent) / 100 : 0.005;
  SETTINGS.requireLowRIR = $('#settingRequireRIR').checked;
  SETTINGS.maxRIR = parseFloat($('#settingMaxRIR').value) || 1;
  SETTINGS.alpha = parseFloat($('#settingAlpha').value) || 0.25;
  SETTINGS.weightStep = parseFloat($('#settingWeightStep').value) || 2.5;
  saveSettingsLocal();
  notify('Settings saved');
  renderExercises();
  renderExerciseList();
}

function resetSettingsToDefaults(){
  SETTINGS = { strategy: 'upperBound', minIncreasePct:0.005, requireLowRIR:true, maxRIR:1, alpha:0.25, weightStep:2.5 };
  saveSettingsLocal();
  reflectSettingsToUI();
  notify('Settings reset to defaults');
  renderExercises();
  renderExerciseList();
}

document.addEventListener('DOMContentLoaded',()=>{
  loadFromStorage();
  loadSettingsLocal();
  $('#dateInput').value = todayYMD();
  $('#dateInput').addEventListener('change', ()=> loadDate($('#dateInput').value));

  $('#copyPrevBtn').addEventListener('click', copyPrevious);
  $('#addExerciseBtn').addEventListener('click', addExercise);
  $('#exportCsvBtn').addEventListener('click', exportCSV);
  $('#addExerciseListBtn').addEventListener('click', addExerciseToList);
  $('#clearWorkoutsBtn').addEventListener('click', clearWorkouts);
  $('#resetExercisesBtn').addEventListener('click', resetExercises);
  $('#clearAllBtn').addEventListener('click', clearAll);
  $('#tab-log').addEventListener('click', ()=> showScreen('#screen-log'));
  $('#tab-exercises').addEventListener('click', ()=> showScreen('#screen-exercises'));
  $('#tab-settings').addEventListener('click', ()=> showScreen('#screen-settings'));

  renderExerciseList();
  loadDate($('#dateInput').value);
  showScreen('#screen-log');

  reflectSettingsToUI();

  $('#saveSettingsBtn').addEventListener('click', applySettingsFromUI);
  $('#resetSettingsBtn').addEventListener('click', ()=>{ if(confirm('Reset settings to defaults?')) resetSettingsToDefaults(); });

  // auto-save on change
  $('#settingStrategy').addEventListener('change', applySettingsFromUI);
  $('#settingMinInc').addEventListener('input', ()=>{});
  $('#settingRequireRIR').addEventListener('change', applySettingsFromUI);
  $('#settingMaxRIR').addEventListener('change', applySettingsFromUI);
  $('#settingAlpha').addEventListener('change', applySettingsFromUI);
  $('#settingWeightStep').addEventListener('change', applySettingsFromUI);

});
