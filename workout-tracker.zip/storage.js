export const STORAGE_KEYS = { workouts: 'wt_workouts_v4', exercises: 'wt_exercises_v3', settings: 'wt_settings_v1' };

export function loadWorkouts(){
  try { return JSON.parse(localStorage.getItem(STORAGE_KEYS.workouts) || '{}'); } catch { return {}; }
}
export function saveWorkouts(workouts){ localStorage.setItem(STORAGE_KEYS.workouts, JSON.stringify(workouts)); }

export function loadExercises(){
  try { return JSON.parse(localStorage.getItem(STORAGE_KEYS.exercises) || '[]'); } catch { return []; }
}
export function saveExercises(exercises){ localStorage.setItem(STORAGE_KEYS.exercises, JSON.stringify(exercises)); }

export function loadSettings(){
  try { return JSON.parse(localStorage.getItem(STORAGE_KEYS.settings) || 'null'); } catch { return null; }
}
export function saveSettings(settings){ localStorage.setItem(STORAGE_KEYS.settings, JSON.stringify(settings)); }
