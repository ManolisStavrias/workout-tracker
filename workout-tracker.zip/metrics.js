export function roundToStep(value, step){ if(!isFinite(value)) return ''; return Math.round(value/step)*step; }

export function calc1RM(kg,reps,rir=0){
  const k = parseFloat(kg);
  const r = parseFloat(reps);
  const extra = parseFloat(rir) || 0;
  const effective = r + extra;
  if(!k || !effective || effective <= 0) return '';
  const epley = k * (1 + effective/30);
  return Math.round(epley*10)/10;
}

export function suggestWeightFrom1RM(stored1RM, targetReps, weightStep){
  if(!stored1RM || !targetReps) return '';
  const denom = 1 + (Number(targetReps) / 30);
  const raw = Number(stored1RM) / denom;
  const rounded = roundToStep(raw, weightStep);
  return rounded || Math.round(raw*10)/10;
}
